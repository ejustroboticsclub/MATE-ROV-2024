This Library is no longer in use, we haven't sold the original style Motorshields for many many years.

Apparently they are now natively supported in https://www.airspayce.com/mikem/arduino/AccelStepper/

So please go there :)
